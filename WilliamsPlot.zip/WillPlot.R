

print("####################### RUN STARTS #############################################")
print("Run Started at: ")
Sys.time()
Sys.Date()

#----------------------------------------------------------------

# direct output to a file
sink("OutPutFile_LOG.txt", append=FALSE, split=TRUE)

#----------------------------------------------------------------
print("This R-program is for Williams plot based evaluation of Regression model for Applicability domain")
print("Written by: Dr. Om Prakash, UGC-DSKPDF/BL/15-16/0291, C/o Prof. U.N. Dwivedi, Department of Biochemistry, Lucknow University, India")
#print("C/o Prof. UN Dwivedi, Lucknow University")
print("")
print("Package MASS needed R>=3.0.0 to run it")
print("The data must contain two sections, as following: ")
print("Descriptor matrix[nxN],Residual col[nx1] i.e. right-last column")
print("put the model's trainging data (i.e. descriptors & residual value) in train.csv named file in program path")
print("put the testing data (i.e. descriptors & residual value) in test.csv named file in program path")
print("For Unknown query compound, Put the residual value ZERO i.e. 0")
print("Get your output details in OutPutFile_LOG.txt & WilliamsPlot.jpg")
print("You can also print the plot by right-clicking on Graph generated")
#print("variable: a (traing data)")
#print("varibale: e (test data)")
#print("varibale: h (Leverage value)")
print("----- Just run and enjoy-------")
print("Note: Your .csv must have numeric entries only")
print("")

#----------------------------------------------------------------

library('MASS')
a0 <-read.csv("train.csv", header = FALSE)
a0_col <-length(a0)
a00 <-a0[,1:a0_col-1] # this is descriptor set of train
a0_resi0 <-a0[,a0_col] # this is Residual column of train
a0_resi = as.matrix(a0_resi0)
resi_boundary = 3*sd(a0_resi)
#print(cat("Standard residual boundary: ",resi_boundary))
#print(a00)
a = as.matrix(a00)
#a <-matrix(1:30,5,6)
#a <- read.table("train.txt", header = FALSE)

#----------------------------------------------------------------

e0 <-read.csv("test.csv", header = FALSE)
#print(e0)
e0_col <-length(e0)
e00 <-e0[,1:e0_col-1] # this is descriptor set of test
e0_resi0 <-e0[,e0_col] # this is Residual column of test
e0_resi = as.matrix(e0_resi0)
#print(e00)
e = as.matrix(e00)
#e <-matrix(1:30,1,6)
#e <- read.table("test.txt", header = FALSE)

#----------------------------------------------------------------

b = t(a)
c = b%*%a
d = ginv(c)

f_train = t(a) # for train set
g_train = d%*%f_train  # for train set
h_train = a%*%g_train  # for train set

f = t(e) # for test set
g = d%*%f  # for test set
h = e%*%g  # for test set
#h

#----------------------------------------------------------------

num_of_desc = a0_col-1
num_of_samples = length(a[,1])
h_star = (3*(num_of_desc+1))/num_of_samples
#print(cat("num_of_desc: ",num_of_desc))
#print(cat("num_of_samples: ",num_of_samples))
#print(cat("h_star: ",h_star))
#print(length(e[,1]))

#----------------------------------------------------------------

print("")
#print("Your traing data in train.csv file is: ")
#print(a)

#print("Your testing data in test.csv file is: ")
#print(e)

#----------------------------------------------------------------

resi_train = matrix(numeric(0), num_of_samples,1)
lev_train = matrix(numeric(0), num_of_samples,1)

resi_test = matrix(numeric(0), length(e0_resi),1)
lev_test = matrix(numeric(0), length(e0_resi),1)


#----------------------------------------------------------------

#Residual of training set
#print("Residual values of train data is: ")
	for(i2 in 1:length(a0_resi))
	{
		#print(a0_resi[i2,])
		resi_train[i2,1] = a0_resi[i2,]
	}

#----------------------------------------------------------------
#Residual of test set
#print("Residual values of test data is: ")
	for(i3 in 1:length(e0_resi))
	{
		#print(e0_resi[i3,])
		resi_test[i3,1] = e0_resi[i3,]

	}

#----------------------------------------------------------------

#print("Leverage values of train data is: ")
x_a <-length(a[,1])
#print(x_a)

	for(ii in 1:x_a)
	{
		#print((h_train[1,ii]))
		lev_train[ii,1] = h_train[1,ii]

	}


#----------------------------------------------------------------

#print("Leverage values of test data is: ")
x <-length(e[,1])
#print(x)

	for(i in 1:x)
	{
		#print((h[1,i]))
		lev_test[i,1] = h[1,i]

	}

#----------------------------------------------------------------
print("----------------------------------------------------------")
print(cat("Standard residual boundary: ",resi_boundary))
print(cat("Leverage boundary: ",h_star))
print("----------------------------------------------------------")
#----------------------------------------------------------------

print("Final Applicability domain analysis result for TRAINING Set")
y <-length(a[,1])
for(i in 1:y){
	if(a0_resi[i,]<=resi_boundary && a0_resi[i,]>=-resi_boundary && h_train[1,i]<=h_star){
		print(cat(a[i,],"\t",a0_resi[i,],"\t",h_train[1,i],"\t","with in Applicability Domain"))
	}else{
		print(cat(a[i,],"\t",a0_resi[i,],"\t",h_train[1,i],"\t","OUT of Applicability Domain"))
		}
}

print("----------------------------------------------------------")
print("")
print("Final Applicability domain analysis result for TEST Set")
x <-length(e[,1])
for(i in 1:x){
	if(e0_resi[i,]<=resi_boundary && e0_resi[i,]>=-resi_boundary && h[1,i]<=h_star){
		print(cat(e[i,],"\t",e0_resi[i,],"\t",h[1,i],"\t","with in Applicability Domain"))
	}else{
		print(cat(e[i,],"\t",e0_resi[i,],"\t",h[1,i],"\t","OUT of Applicability Domain"))
		}
}

#----------------------------------------------------------------

#library(ggplot2)

#plot(lev_train~resi_train,col="blue")
#plot(lev_test~resi_test,col="red")


#x <- c(-2,-0.3,1.4,2.4,4.5)
#y <- c(5,-0.5,8,2,11)
#plot(x,y,type="b",col="blue",xlab="Advertise Change",ylab="Revenue Change", main="Financial Analysis")
#abline(v=0,col="red") #add a vertical line at x=0

#x2 <- c(-1.5,1,4)
#y2 <- c(3,2,8)
#lines(x2,y2,col="darkolivegreen3")
#abline(h=0,col="blue") #add a vertical line at y=0


#plot(lev_train,resi_train,type="b",col="blue",xlab="Leverages",ylab="Standard Residual values", main="Williams Plot by Om Prakash C/o Prof. UN Dwivedi, Lucknow University, UP, India",pch=19,ylim=c(-(resi_boundary+2),(resi_boundary+2)),xlim=c(-(h_star+1),(h_star+1)))
#lines(lev_test,resi_test,col="darkolivegreen3")
#abline(v=h_star,col="red") #add a vertical line at x=0
#abline(h=resi_boundary,col="blue") #add a vertical line at x=0
#abline(h=-resi_boundary,col="blue") #add a vertical line at x=0

#tiff("WilliamsPlot.tif", res = 300)
plot(lev_train,resi_train,type="p",col="blue",xlab="Leverages",ylab="Standard Residual values", main="Williams Plot",pch=19,ylim=c(-(resi_boundary+2),(resi_boundary+2)),xlim=c(-(h_star+1),(h_star+1)))
lines(lev_test,resi_test,type="p",col="red")
abline(v=h_star,col="red") #add a vertical line at x=0
abline(h=resi_boundary,col="blue") #add a vertical line at x=0
abline(h=-resi_boundary,col="blue") #add a vertical line at x=0
dev.copy(jpeg,filename="WilliamsPlot.jpg");
dev.off ();


#----------------------------------------------------------------
 
# return output to the terminal 
sink()

#----------------------------------------------------------------

print("")
print("####################### RUN ENDS #############################################")
